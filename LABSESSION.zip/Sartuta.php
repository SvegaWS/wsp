<?php

	echo 'Logina ondo egin da, ongi etorri';
?>